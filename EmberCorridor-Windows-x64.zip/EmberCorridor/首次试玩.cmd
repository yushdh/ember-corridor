@echo off
start "" "%~dp0EmberCorridor.exe" --first-play
